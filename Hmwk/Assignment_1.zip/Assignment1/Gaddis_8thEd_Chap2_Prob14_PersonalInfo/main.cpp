/* 
 * File:   main.cpp
 * Author: Brandon Smith
 * Created on June 24, 2022
 * Purpose: HMWK 1
 *          Print 4 pieces of personal info on separate line using one "cout"
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map inputs to outputs -> The Process
    
    //Display Results
    cout<<"My name is Brandon Smith."<<endl
            <<"I live at 4270 San Sebasatian Circle, Corona CA, 92882."<<endl
            <<"My cellphone number is 714-308-8372."<<endl
            <<"My college major is Computer Science!"<<endl;
    //Feels weird putting my personal info in my code
    
    //Exit stage right
        return 0;
}

