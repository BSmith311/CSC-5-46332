/* 
 * File:   main.cpp
 * Author: Brandon Smith
 * Created on June 23, 2022
 * Purpose: Hmwk 1
 *          Store and add 2 integers
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    unsigned short variableOne, variableTwo, total;
    //Initialize Variables
    variableOne=50;
    variableTwo=100;
    //Map inputs to outputs -> The Process
    total=variableOne+variableTwo;
    //Display Results
    cout<<"The sum of "<<variableOne<<" and "<<variableTwo<<" is "<<total;
    //Exit stage right
        return 0;
}

